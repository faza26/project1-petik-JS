var tombol = document.getElementById("click")

    function UbahTeks() {
        document.getElementById("teks").innerText = "Teks Telah diubah";
    }
    
    tombol.addEventListener("mousewheel", UbahTeks );