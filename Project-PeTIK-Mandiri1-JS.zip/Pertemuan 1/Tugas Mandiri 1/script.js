document.write("<h2> Halaman Login by Aufa Zaki</h2>")

    var username = document.createElement("input");
    username.setAttribute("type", "text");
    username.setAttribute("placeholder", "Username");
    document.body.appendChild(username);

    document.write("<br><br>");

    var password = document.createElement("input");
    password.setAttribute("type", "password");
    password.setAttribute("placeholder", "Password");
    document.body.appendChild(password);

    document.write("<br><br>");

    var btn = document.createElement("button");
    btn.innerHTML = "Login";
    btn.type = "submit";
    document.body.appendChild(btn);